执行下面两个命令实现一键配置vim  
chmod +x auto.sh  
./auto.sh
